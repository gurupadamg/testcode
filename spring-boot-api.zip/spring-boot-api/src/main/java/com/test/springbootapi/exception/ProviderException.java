package com.test.springbootapi.exception;

public class ProviderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProviderException(String message) {
		super(message);

	}

}
