package com.test.springbootapi.constants;

public class ProviderConstants {
	public static final String INTERNAL_SERVER_ERROR = "OGSIS100";
}
